#!/usr/bin/env bash
# ============================================================
# Ubuntu Terminal MCP Server — Installer for OpenCode
# ============================================================
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SERVER_PY="$SCRIPT_DIR/server.py"
PYTHON_BIN="$(which python3)"
GLOBAL_CONFIG_DIR="$HOME/.config/opencode"
GLOBAL_CONFIG="$GLOBAL_CONFIG_DIR/opencode.jsonc"

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║  Ubuntu Terminal MCP Server — OpenCode Installer     ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# ── 1. Check Python 3.10+ ────────────────────────────────────────────────────
echo "→ Checking Python version..."
PY_VER=$($PYTHON_BIN -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
echo "  Found Python $PY_VER"
if ! $PYTHON_BIN -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)"; then
    echo "  ❌ Python 3.10+ required. Install it first."
    exit 1
fi
echo "  ✅ Python version OK"

# ── 2. Install the MCP library ───────────────────────────────────────────────
echo ""
echo "→ Installing MCP Python library..."
pip3 install mcp --break-system-packages --quiet --ignore-installed 2>/dev/null \
  || pip3 install mcp --quiet 2>/dev/null \
  || { echo "  ❌ pip install failed."; exit 1; }
echo "  ✅ MCP library installed"

# ── 3. Make server.py executable ─────────────────────────────────────────────
echo ""
echo "→ Making server executable..."
chmod +x "$SERVER_PY"
echo "  ✅ $SERVER_PY is executable"

# ── 4. Syntax check ───────────────────────────────────────────────────────────
echo ""
echo "→ Running syntax check..."
$PYTHON_BIN -c "import ast; ast.parse(open('$SERVER_PY').read()); print('  ✅ Syntax OK')"

# ── 5. Write OpenCode config ──────────────────────────────────────────────────
echo ""
echo "Where do you want to register the MCP server?"
echo "  1) Globally  — works in ALL your OpenCode sessions (~/.config/opencode/opencode.jsonc)"
echo "  2) Project   — works only in this directory (./opencode.jsonc)"
read -r -p "  Choose [1/2, default=1]: " scope_choice
scope_choice="${scope_choice:-1}"

MCP_BLOCK=$(cat <<JSON
{
  "\$schema": "https://opencode.ai/config.json",
  "mcp": {
    "ubuntu-terminal": {
      "type": "local",
      "command": ["$PYTHON_BIN", "$SERVER_PY"],
      "enabled": true,
      "environment": {}
    }
  }
}
JSON
)

if [[ "$scope_choice" == "2" ]]; then
    TARGET="$(pwd)/opencode.jsonc"
    echo "$MCP_BLOCK" > "$TARGET"
    echo "  ✅ Written to $TARGET"
else
    mkdir -p "$GLOBAL_CONFIG_DIR"
    if [[ -f "$GLOBAL_CONFIG" ]]; then
        echo ""
        echo "  ⚠️  A global config already exists at $GLOBAL_CONFIG"
        echo "     Add this block manually under the \"mcp\" key:"
        echo ""
        echo '    "ubuntu-terminal": {'
        echo "      \"type\": \"local\","
        echo "      \"command\": [\"$PYTHON_BIN\", \"$SERVER_PY\"],"
        echo '      "enabled": true,'
        echo '      "environment": {}'
        echo '    }'
        echo ""
    else
        echo "$MCP_BLOCK" > "$GLOBAL_CONFIG"
        echo "  ✅ Written to $GLOBAL_CONFIG"
    fi
fi

# ── 6. Done ───────────────────────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════════════════════════════╗"
echo "║  Setup complete! To verify:                                     ║"
echo "║                                                                  ║"
echo "║  1. Start OpenCode:                                              ║"
echo "║       opencode                                                   ║"
echo "║                                                                  ║"
echo "║  2. List MCP servers (in a new terminal):                        ║"
echo "║       opencode mcp list                                          ║"
echo "║                                                                  ║"
echo "║  3. You should see 'ubuntu-terminal' listed as connected.        ║"
echo "╚══════════════════════════════════════════════════════════════════╝"
echo ""
echo "Done! 🎉"
