#!/usr/bin/env python3
"""
Ubuntu Terminal MCP Server
Gives Claude Code (or any MCP client) full access to your Ubuntu terminal.
Supports: run commands, read/write files, manage processes, and more.
"""

import asyncio
import os
import subprocess
import shutil
import signal
import pwd
import grp
import stat
from pathlib import Path
from datetime import datetime
from mcp.server import FastMCP

# ── Safety: commands that are ALWAYS blocked ─────────────────────────────────
BLOCKED_COMMANDS = [
    "rm -rf /",
    "dd if=/dev/zero",
    "mkfs",
    ":(){:|:&};:",   # fork bomb
    "chmod -R 777 /",
    "chown -R",
]

def is_blocked(cmd: str) -> bool:
    cmd_lower = cmd.lower().strip()
    return any(blocked in cmd_lower for blocked in BLOCKED_COMMANDS)

# ─────────────────────────────────────────────────────────────────────────────
mcp = FastMCP("ubuntu-terminal")

# ── 1. Run a shell command ────────────────────────────────────────────────────
@mcp.tool()
async def run_command(
    command: str,
    working_dir: str = "",
    timeout: int = 60,
    shell: bool = True,
) -> str:
    """
    Execute a shell command on the Ubuntu machine and return its output.

    Args:
        command:     The shell command to run (e.g. "ls -la /home").
        working_dir: Directory to run it in. Defaults to the user's home dir.
        timeout:     Max seconds to wait before killing the process (default 60).
        shell:       Use /bin/bash -c to run (default True).

    Returns:
        stdout + stderr combined, with exit code appended.
    """
    if is_blocked(command):
        return "❌ BLOCKED: This command matches a dangerous pattern and will not run."

    cwd = os.path.expanduser(working_dir) if working_dir else os.path.expanduser("~")
    if not os.path.isdir(cwd):
        return f"❌ Directory does not exist: {cwd}"

    try:
        proc = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            cwd=cwd,
            env={**os.environ, "TERM": "xterm-256color"},
        )
        try:
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except asyncio.TimeoutError:
            proc.kill()
            await proc.communicate()
            return f"⏰ Command timed out after {timeout}s: {command}"

        output = stdout.decode("utf-8", errors="replace")
        exit_code = proc.returncode
        status = "✅" if exit_code == 0 else f"⚠️ (exit {exit_code})"
        return f"{status}\n{output}" if output.strip() else f"{status} (no output)"

    except Exception as e:
        return f"❌ Error running command: {e}"


# ── 2. Read a file ────────────────────────────────────────────────────────────
@mcp.tool()
async def read_file(path: str, max_lines: int = 500) -> str:
    """
    Read a file from the filesystem and return its contents.

    Args:
        path:      Absolute or ~/relative path to the file.
        max_lines: Maximum number of lines to return (default 500).

    Returns:
        File contents as text, or an error message.
    """
    full_path = Path(os.path.expanduser(path))
    if not full_path.exists():
        return f"❌ File not found: {path}"
    if not full_path.is_file():
        return f"❌ Not a file: {path}"
    if full_path.stat().st_size > 10 * 1024 * 1024:  # 10 MB guard
        return f"❌ File too large to read (>10 MB): {path}"

    try:
        lines = full_path.read_text(errors="replace").splitlines()
        truncated = len(lines) > max_lines
        shown = lines[:max_lines]
        content = "\n".join(shown)
        note = f"\n\n[...truncated at {max_lines} lines, total {len(lines)} lines]" if truncated else ""
        return content + note
    except Exception as e:
        return f"❌ Could not read file: {e}"


# ── 3. Write / overwrite a file ───────────────────────────────────────────────
@mcp.tool()
async def write_file(path: str, content: str, append: bool = False) -> str:
    """
    Write text content to a file (creates it if it does not exist).

    Args:
        path:    Absolute or ~/relative path to the file.
        content: Text to write.
        append:  If True, append to the file instead of overwriting.

    Returns:
        Success message or error.
    """
    full_path = Path(os.path.expanduser(path))
    full_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        mode = "a" if append else "w"
        with open(full_path, mode, encoding="utf-8") as f:
            f.write(content)
        action = "Appended to" if append else "Wrote"
        return f"✅ {action} {full_path} ({len(content)} chars)"
    except Exception as e:
        return f"❌ Could not write file: {e}"


# ── 4. List directory contents ────────────────────────────────────────────────
@mcp.tool()
async def list_directory(path: str = "~", show_hidden: bool = False) -> str:
    """
    List files and directories inside a given path.

    Args:
        path:        Directory to list. Defaults to home directory.
        show_hidden: Include files starting with '.' (default False).

    Returns:
        Formatted directory listing with sizes and permissions.
    """
    full_path = Path(os.path.expanduser(path))
    if not full_path.exists():
        return f"❌ Path not found: {path}"
    if not full_path.is_dir():
        return f"❌ Not a directory: {path}"

    try:
        entries = sorted(full_path.iterdir(), key=lambda e: (not e.is_dir(), e.name.lower()))
        lines = [f"📁 {full_path}\n"]
        for entry in entries:
            if not show_hidden and entry.name.startswith("."):
                continue
            try:
                s = entry.stat()
                size = s.st_size
                mtime = datetime.fromtimestamp(s.st_mtime).strftime("%Y-%m-%d %H:%M")
                perms = stat.filemode(s.st_mode)
                icon = "📂" if entry.is_dir() else "📄"
                size_str = f"{size:>10,}" if not entry.is_dir() else "          "
                lines.append(f"  {icon} {perms}  {size_str}  {mtime}  {entry.name}")
            except PermissionError:
                lines.append(f"  🔒 (permission denied)  {entry.name}")
        return "\n".join(lines) if len(lines) > 1 else f"📁 {full_path}\n  (empty)"
    except Exception as e:
        return f"❌ Error listing directory: {e}"


# ── 5. Get system information ─────────────────────────────────────────────────
@mcp.tool()
async def system_info() -> str:
    """
    Return a snapshot of the Ubuntu system: OS, CPU, memory, disk, uptime.
    No arguments needed.
    """
    cmds = {
        "OS":      "lsb_release -ds 2>/dev/null || cat /etc/os-release | grep PRETTY_NAME | cut -d= -f2",
        "Kernel":  "uname -r",
        "CPU":     "grep 'model name' /proc/cpuinfo | head -1 | cut -d: -f2",
        "Cores":   "nproc",
        "Memory":  "free -h | awk '/^Mem/{print $3\"/\"$2}'",
        "Disk":    "df -h / | awk 'NR==2{print $3\"/\"$2\" used (\"$5\")\"}'",
        "Uptime":  "uptime -p",
        "User":    "whoami",
        "Hostname":"hostname",
        "IP":      "hostname -I | awk '{print $1}'",
    }
    lines = ["🖥️  Ubuntu System Information\n" + "─"*40]
    for label, cmd in cmds.items():
        try:
            result = subprocess.check_output(cmd, shell=True, text=True, stderr=subprocess.DEVNULL).strip()
            lines.append(f"  {label:<12}: {result}")
        except Exception:
            lines.append(f"  {label:<12}: (unavailable)")
    return "\n".join(lines)


# ── 6. List running processes ─────────────────────────────────────────────────
@mcp.tool()
async def list_processes(filter_name: str = "") -> str:
    """
    Show running processes, optionally filtered by name.

    Args:
        filter_name: Only show processes whose name/command contains this string.

    Returns:
        Formatted process list (PID, CPU%, MEM%, command).
    """
    cmd = "ps aux --no-headers --sort=-%cpu"
    try:
        output = subprocess.check_output(cmd, shell=True, text=True)
        lines = output.strip().splitlines()
        if filter_name:
            lines = [l for l in lines if filter_name.lower() in l.lower()]
        if not lines:
            return f"No processes found matching '{filter_name}'"
        rows = ["PID       CPU%  MEM%  COMMAND", "─"*60]
        for line in lines[:40]:  # cap at 40 rows
            parts = line.split(None, 10)
            if len(parts) >= 11:
                pid, cpu, mem, cmd_col = parts[1], parts[2], parts[3], parts[10]
                rows.append(f"{pid:<9} {cpu:<5} {mem:<5} {cmd_col[:80]}")
        return "\n".join(rows)
    except Exception as e:
        return f"❌ Error listing processes: {e}"


# ── 7. Kill a process by PID ──────────────────────────────────────────────────
@mcp.tool()
async def kill_process(pid: int, force: bool = False) -> str:
    """
    Kill a process by its PID.

    Args:
        pid:   Process ID to kill.
        force: Use SIGKILL (-9) instead of SIGTERM (default False).

    Returns:
        Success or error message.
    """
    sig = signal.SIGKILL if force else signal.SIGTERM
    sig_name = "SIGKILL" if force else "SIGTERM"
    try:
        os.kill(pid, sig)
        return f"✅ Sent {sig_name} to PID {pid}"
    except ProcessLookupError:
        return f"❌ No process with PID {pid}"
    except PermissionError:
        return f"❌ Permission denied to kill PID {pid} (try with sudo in run_command)"
    except Exception as e:
        return f"❌ Error: {e}"


# ── 8. Create a directory ─────────────────────────────────────────────────────
@mcp.tool()
async def make_directory(path: str) -> str:
    """
    Create a directory (and all parents) at the given path.

    Args:
        path: Absolute or ~/relative path to create.

    Returns:
        Success or error message.
    """
    full_path = Path(os.path.expanduser(path))
    try:
        full_path.mkdir(parents=True, exist_ok=True)
        return f"✅ Directory created: {full_path}"
    except Exception as e:
        return f"❌ Error creating directory: {e}"


# ── 9. Delete a file or directory ────────────────────────────────────────────
@mcp.tool()
async def delete_path(path: str, recursive: bool = False) -> str:
    """
    Delete a file or directory.

    Args:
        path:      Absolute or ~/relative path to delete.
        recursive: If True, delete directories and their contents (like rm -r).
                   Required for non-empty directories.

    Returns:
        Success or error message.
    """
    full_path = Path(os.path.expanduser(path))

    # Safety: never delete root or home
    for dangerous in ["/", "/home", "/usr", "/etc", "/var", "/sys", "/proc"]:
        if str(full_path).rstrip("/") == dangerous:
            return f"❌ BLOCKED: Refusing to delete critical system path: {full_path}"

    if not full_path.exists():
        return f"❌ Path not found: {path}"

    try:
        if full_path.is_file() or full_path.is_symlink():
            full_path.unlink()
            return f"✅ Deleted file: {full_path}"
        elif full_path.is_dir():
            if not recursive:
                # Only delete if empty
                if any(full_path.iterdir()):
                    return f"❌ Directory not empty. Use recursive=True to delete it and its contents."
                full_path.rmdir()
            else:
                shutil.rmtree(full_path)
            return f"✅ Deleted directory: {full_path}"
    except Exception as e:
        return f"❌ Error deleting path: {e}"


# ── 10. Copy or move a file/directory ────────────────────────────────────────
@mcp.tool()
async def copy_or_move(src: str, dst: str, move: bool = False) -> str:
    """
    Copy or move a file or directory.

    Args:
        src:  Source path (absolute or ~/ relative).
        dst:  Destination path (absolute or ~/ relative).
        move: If True, move instead of copy (default False = copy).

    Returns:
        Success or error message.
    """
    src_path = Path(os.path.expanduser(src))
    dst_path = Path(os.path.expanduser(dst))

    if not src_path.exists():
        return f"❌ Source not found: {src}"

    dst_path.parent.mkdir(parents=True, exist_ok=True)
    action = "Moved" if move else "Copied"
    try:
        if move:
            shutil.move(str(src_path), str(dst_path))
        elif src_path.is_dir():
            shutil.copytree(str(src_path), str(dst_path), dirs_exist_ok=True)
        else:
            shutil.copy2(str(src_path), str(dst_path))
        return f"✅ {action}: {src_path} → {dst_path}"
    except Exception as e:
        return f"❌ Error: {e}"


# ── 11. Search for files ──────────────────────────────────────────────────────
@mcp.tool()
async def find_files(
    search_dir: str = "~",
    pattern: str = "*",
    file_type: str = "both",
    max_results: int = 50,
) -> str:
    """
    Search for files or directories matching a pattern.

    Args:
        search_dir:  Directory to search in (default: home directory).
        pattern:     Glob pattern like '*.py', '*.log', 'config*' (default '*').
        file_type:   'file', 'dir', or 'both' (default 'both').
        max_results: Maximum number of results to return (default 50).

    Returns:
        List of matching paths.
    """
    base = Path(os.path.expanduser(search_dir))
    if not base.exists():
        return f"❌ Directory not found: {search_dir}"

    try:
        results = []
        for p in base.rglob(pattern):
            if file_type == "file" and not p.is_file():
                continue
            if file_type == "dir" and not p.is_dir():
                continue
            results.append(str(p))
            if len(results) >= max_results:
                break

        if not results:
            return f"No results for pattern '{pattern}' in {base}"
        header = f"🔍 Found {len(results)} result(s) for '{pattern}' in {base}:\n"
        return header + "\n".join(results)
    except Exception as e:
        return f"❌ Error searching: {e}"


# ── 12. Check disk, memory, and CPU usage ─────────────────────────────────────
@mcp.tool()
async def resource_usage() -> str:
    """
    Show current CPU, memory, and disk usage in a human-readable format.
    No arguments needed.
    """
    cmds = [
        ("CPU Usage",    "top -bn1 | grep 'Cpu(s)' | awk '{print 100-$8\"%\"}'"),
        ("Memory",       "free -h"),
        ("Disk Usage",   "df -h | grep -v tmpfs | grep -v udev"),
        ("Top Processes","ps aux --sort=-%cpu --no-headers | head -5 | awk '{print $2, $3\"%\", $4\"%\", $11}'"),
    ]
    sections = []
    for title, cmd in cmds:
        try:
            out = subprocess.check_output(cmd, shell=True, text=True, stderr=subprocess.DEVNULL).strip()
            sections.append(f"── {title} ──\n{out}")
        except Exception:
            sections.append(f"── {title} ──\n(unavailable)")
    return "\n\n".join(sections)


# ── 13. Environment variables ─────────────────────────────────────────────────
@mcp.tool()
async def get_env(variable_name: str = "") -> str:
    """
    Get the value of an environment variable, or list all of them.

    Args:
        variable_name: Name of the env var (e.g. 'PATH'). If empty, list all.

    Returns:
        Variable value or full environment listing.
    """
    if variable_name:
        val = os.environ.get(variable_name)
        if val is None:
            return f"❌ Environment variable '{variable_name}' not set."
        return f"{variable_name}={val}"
    else:
        lines = [f"{k}={v}" for k, v in sorted(os.environ.items())]
        return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("🚀 Ubuntu Terminal MCP Server starting on stdio transport...", flush=True)
    mcp.run(transport="stdio")
